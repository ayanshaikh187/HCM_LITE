import React, { useState, useEffect } from 'react';
import axios from 'axios';

const PayrollManagement = () => {
  const [payrollDraft, setPayrollDraft] = useState([]);
  const [month, setMonth] = useState('October 2026');
  const [isFinalized, setIsFinalized] = useState(false);
  const [loading, setLoading] = useState(true);
  const user = JSON.parse(localStorage.getItem('user') || '{}');

  useEffect(() => {
    fetchPayroll();
  }, [month]);

  const fetchPayroll = async () => {
    try {
      const token = localStorage.getItem('token');
      const config = { headers: { Authorization: `Bearer ${token}` } };
      const res = await axios.get(`http://localhost:5000/api/payroll?month=${month}`, config);
      setPayrollDraft(res.data.records || []);
      setIsFinalized(res.data.isFinalized || false);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleGenerateDraft = async () => {
    try {
      const token = localStorage.getItem('token');
      await axios.post(
        'http://localhost:5000/api/payroll/generate',
        { month },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      alert('Payroll draft generated!');
      fetchPayroll();
    } catch (err) {
      alert(err.response?.data?.message || 'Error generating draft');
    }
  };

  const handleFinalizePayroll = async () => {
    if (!window.confirm('Are you sure? Once finalized, the payroll run for this month will be LOCKED.')) return;
    try {
      const token = localStorage.getItem('token');
      await axios.post(
        'http://localhost:5000/api/payroll/finalize',
        { month },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      alert('Payroll finalized and locked successfully!');
      setIsFinalized(true);
    } catch (err) {
      alert(err.response?.data?.message || 'Only Admin can finalize payroll');
    }
  };

  const handleDownloadPayslip = async (employeeId) => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(
        `http://localhost:5000/api/payroll/payslip/${employeeId}?month=${month}`,
        { headers: { Authorization: `Bearer ${token}` }, responseType: 'blob' }
      );
      
      const blob = new Blob([response.data], { type: 'application/pdf' });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `Payslip_${month}_${employeeId}.pdf`);
      document.body.appendChild(link);
      link.click();
    } catch (err) {
      alert('Failed to download payslip PDF');
    }
  };

  return (
    <div className="p-8 bg-gray-950 text-white min-h-screen">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h2 className="text-3xl font-bold">Payroll Lite</h2>
          <p className="text-gray-400 text-sm mt-1">Monthly calculations, tax slabs, and payslips</p>
        </div>

        <div className="flex gap-3 items-center">
          <select
            value={month}
            onChange={(e) => setMonth(e.target.value)}
            className="px-4 py-2 bg-gray-900 border border-gray-800 rounded-lg text-white text-sm"
          >
            <option value="October 2026">October 2026</option>
            <option value="September 2026">September 2026</option>
          </select>

          {(user.role === 'HR' || user.role === 'Admin') && !isFinalized && (
            <button
              onClick={handleGenerateDraft}
              className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg text-sm font-semibold"
            >
              Generate Draft
            </button>
          )}

          {user.role === 'Admin' && !isFinalized && payrollDraft.length > 0 && (
            <button
              onClick={handleFinalizePayroll}
              className="bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 rounded-lg text-sm font-semibold"
            >
              🔒 Finalize & Lock
            </button>
          )}

          {isFinalized && (
            <span className="bg-emerald-500/10 border border-emerald-500 text-emerald-400 px-3 py-1.5 rounded-lg text-xs font-semibold">
              Status: Finalized
            </span>
          )}
        </div>
      </div>

      <div className="bg-gray-900 border border-gray-800 rounded-xl overflow-hidden shadow-xl">
        <table className="w-full text-left border-collapse">
          <thead className="bg-gray-850 text-gray-400 border-b border-gray-800 text-sm">
            <tr>
              <th className="p-4">Employee</th>
              <th className="p-4">Basic Pay</th>
              <th className="p-4">Allowances</th>
              <th className="p-4">Deductions</th>
              <th className="p-4">Tax</th>
              <th className="p-4">Net Salary</th>
              <th className="p-4 text-center">Payslip</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-800 text-sm">
            {payrollDraft.length > 0 ? (
              payrollDraft.map((row, idx) => (
                <tr key={idx} className="hover:bg-gray-850">
                  <td className="p-4 font-medium text-indigo-300">{row.employeeName}</td>
                  <td className="p-4 text-gray-300">${row.basic}</td>
                  <td className="p-4 text-gray-300">${row.allowances}</td>
                  <td className="p-4 text-red-400">-${row.deductions}</td>
                  <td className="p-4 text-amber-400">-${row.tax}</td>
                  <td className="p-4 font-bold text-green-400">${row.netSalary}</td>
                  <td className="p-4 text-center">
                    <button
                      onClick={() => handleDownloadPayslip(row.employeeId)}
                      className="px-3 py-1 bg-gray-800 hover:bg-gray-700 text-indigo-300 border border-gray-700 rounded text-xs"
                    >
                      📄 Download PDF
                    </button>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="7" className="p-6 text-center text-gray-500">
                  No payroll draft generated for {month}.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default PayrollManagement;