import React, { useState, useEffect } from 'react';
import axios from 'axios';

const AttendanceBoard = () => {
  const [attendance, setAttendance] = useState([]);
  const [myStatus, setMyStatus] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showCorrectionModal, setShowCorrectionModal] = useState(false);
  const [correctionReason, setCorrectionReason] = useState('');
  const user = JSON.parse(localStorage.getItem('user') || '{}');

  useEffect(() => {
    fetchAttendance();
  }, []);

  const fetchAttendance = async () => {
    try {
      const token = localStorage.getItem('token');
      const config = { headers: { Authorization: `Bearer ${token}` } };
      
      // Fetch daily attendance records
      const res = await axios.get('http://localhost:5000/api/attendance', config);
      setAttendance(res.data.records || []);
      setMyStatus(res.data.todayStatus || null);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleCheckIn = async () => {
    try {
      const token = localStorage.getItem('token');
      const res = await axios.post(
        'http://localhost:5000/api/attendance/check-in',
        {},
        { headers: { Authorization: `Bearer ${token}` } }
      );
      alert(res.data.message || 'Check-in successful!');
      fetchAttendance();
    } catch (err) {
      alert(err.response?.data?.message || 'Check-in failed');
    }
  };

  const handleCheckOut = async () => {
    try {
      const token = localStorage.getItem('token');
      const res = await axios.post(
        'http://localhost:5000/api/attendance/check-out',
        {},
        { headers: { Authorization: `Bearer ${token}` } }
      );
      alert(res.data.message || 'Check-out successful!');
      fetchAttendance();
    } catch (err) {
      alert(err.response?.data?.message || 'Check-out failed');
    }
  };

  const handleRequestCorrection = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem('token');
      await axios.post(
        'http://localhost:5000/api/attendance/correction',
        { reason: correctionReason },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      alert('Correction request submitted to HR!');
      setShowCorrectionModal(false);
      setCorrectionReason('');
    } catch (err) {
      alert(err.response?.data?.message || 'Failed to submit correction request');
    }
  };

  if (loading) return <div className="p-8 text-white">Loading Attendance Board...</div>;

  return (
    <div className="p-8 bg-gray-950 text-white min-h-screen">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h2 className="text-3xl font-bold">Attendance Board</h2>
          <p className="text-gray-400 text-sm mt-1">Daily check-in logs and status tracking</p>
        </div>
        
        <div className="flex gap-3">
          {!myStatus?.checkIn ? (
            <button
              onClick={handleCheckIn}
              className="bg-green-600 hover:bg-green-700 text-white px-5 py-2.5 rounded-lg font-semibold transition"
            >
              Check In
            </button>
          ) : !myStatus?.checkOut ? (
            <button
              onClick={handleCheckOut}
              className="bg-amber-600 hover:bg-amber-700 text-white px-5 py-2.5 rounded-lg font-semibold transition"
            >
              Check Out
            </button>
          ) : (
            <span className="bg-gray-800 text-gray-300 px-4 py-2 rounded-lg text-sm font-medium border border-gray-700">
              Completed Today
            </span>
          )}

          <button
            onClick={() => setShowCorrectionModal(true)}
            className="bg-gray-800 hover:bg-gray-700 text-gray-200 px-4 py-2.5 rounded-lg text-sm font-medium border border-gray-700"
          >
            Request Correction
          </button>
        </div>
      </div>

      {/* Attendance Log Table */}
      <div className="bg-gray-900 border border-gray-800 rounded-xl overflow-hidden shadow-xl">
        <table className="w-full text-left border-collapse">
          <thead className="bg-gray-850 text-gray-400 border-b border-gray-800 text-sm">
            <tr>
              <th className="p-4">Employee</th>
              <th className="p-4">Date</th>
              <th className="p-4">Check In</th>
              <th className="p-4">Check Out</th>
              <th className="p-4">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-800 text-sm">
            {attendance.length > 0 ? (
              attendance.map((rec, idx) => (
                <tr key={idx} className="hover:bg-gray-850">
                  <td className="p-4 font-medium text-indigo-300">{rec.employeeName}</td>
                  <td className="p-4 text-gray-300">{rec.date}</td>
                  <td className="p-4 text-gray-300">{rec.checkIn || '--:--'}</td>
                  <td className="p-4 text-gray-300">{rec.checkOut || '--:--'}</td>
                  <td className="p-4">
                    <span
                      className={`px-3 py-1 rounded-full text-xs font-semibold ${
                        rec.status === 'Present'
                          ? 'bg-green-500/10 text-green-400 border border-green-500/30'
                          : rec.status === 'Late'
                          ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                          : 'bg-red-500/10 text-red-400 border border-red-500/30'
                      }`}
                    >
                      {rec.status}
                    </span>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="5" className="p-6 text-center text-gray-500">
                  No attendance records logged for today yet.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Correction Modal */}
      {showCorrectionModal && (
        <div className="fixed inset-0 bg-black/75 flex items-center justify-center p-4">
          <div className="bg-gray-900 border border-gray-800 rounded-xl p-6 max-w-md w-full shadow-2xl">
            <h3 className="text-xl font-bold text-white mb-2">Request Attendance Correction</h3>
            <p className="text-gray-400 text-sm mb-4">Provide a valid reason for HR review.</p>
            <form onSubmit={handleRequestCorrection} className="space-y-4">
              <textarea
                required
                rows="4"
                value={correctionReason}
                onChange={(e) => setCorrectionReason(e.target.value)}
                placeholder="E.g., System failed to register my checkout at 5:00 PM."
                className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:outline-none focus:border-indigo-500"
              ></textarea>
              <div className="flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowCorrectionModal(false)}
                  className="px-4 py-2 bg-gray-800 text-gray-300 rounded-lg"
                >
                  Cancel
                </button>
                <button type="submit" className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-lg">
                  Submit
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default AttendanceBoard;