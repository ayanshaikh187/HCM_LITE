import React, { useState, useEffect } from 'react';
import axios from 'axios';

const EmployeeDirectory = () => {
  const [employees, setEmployees] = useState([]);
  const [search, setSearch] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [newEmp, setNewEmp] = useState({ name: '', email: '', department: '', designation: '', basicSalary: '' });

  useEffect(() => {
    fetchEmployees();
  }, [search]);

  const fetchEmployees = async () => {
    try {
      const token = localStorage.getItem('token');
      const res = await axios.get(`http://localhost:5000/api/employees?search=${search}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setEmployees(res.data);
    } catch (err) {
      console.error(err);
    }
  };

  const handleCreateEmployee = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem('token');
      await axios.post('http://localhost:5000/api/employees', newEmp, {
        headers: { Authorization: `Bearer ${token}` },
      });
      alert('Employee registered successfully! Login credentials generated.');
      setShowModal(false);
      fetchEmployees();
    } catch (err) {
      alert(err.response?.data?.message || 'Error registering employee');
    }
  };

  return (
    <div className="p-8 bg-gray-950 text-white min-h-screen">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-3xl font-bold">Employee Directory</h2>
        <button
          onClick={() => setShowModal(true)}
          className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg font-medium"
        >
          + Register Employee
        </button>
      </div>

      <div className="mb-6">
        <input
          type="text"
          placeholder="Search by name, department, email..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full max-w-md px-4 py-2 bg-gray-900 border border-gray-800 rounded-lg text-white"
        />
      </div>

      <div className="bg-gray-900 border border-gray-800 rounded-lg overflow-hidden">
        <table className="w-full text-left border-collapse">
          <thead className="bg-gray-850 text-gray-400 border-b border-gray-800 text-sm">
            <tr>
              <th className="p-4">Name</th>
              <th className="p-4">Email</th>
              <th className="p-4">Department</th>
              <th className="p-4">Designation</th>
              <th className="p-4">Salary</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-800 text-sm">
            {employees.map((emp) => (
              <tr key={emp._id} className="hover:bg-gray-850">
                <td className="p-4 font-medium text-indigo-300">{emp.name}</td>
                <td className="p-4 text-gray-300">{emp.email}</td>
                <td className="p-4 text-gray-400">{emp.department}</td>
                <td className="p-4 text-gray-400">{emp.designation}</td>
                <td className="p-4 text-gray-300">${emp.basicSalary}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center p-4">
          <div className="bg-gray-900 border border-gray-800 rounded-lg p-6 max-w-md w-full">
            <h3 className="text-xl font-bold mb-4">Register New Employee</h3>
            <form onSubmit={handleCreateEmployee} className="space-y-4">
              <input type="text" placeholder="Full Name" required className="w-full p-2 bg-gray-800 rounded text-white" onChange={(e) => setNewEmp({ ...newEmp, name: e.target.value })} />
              <input type="email" placeholder="Email" required className="w-full p-2 bg-gray-800 rounded text-white" onChange={(e) => setNewEmp({ ...newEmp, email: e.target.value })} />
              <input type="text" placeholder="Department" required className="w-full p-2 bg-gray-800 rounded text-white" onChange={(e) => setNewEmp({ ...newEmp, department: e.target.value })} />
              <input type="text" placeholder="Designation" required className="w-full p-2 bg-gray-800 rounded text-white" onChange={(e) => setNewEmp({ ...newEmp, designation: e.target.value })} />
              <input type="number" placeholder="Basic Salary" required className="w-full p-2 bg-gray-800 rounded text-white" onChange={(e) => setNewEmp({ ...newEmp, basicSalary: e.target.value })} />
              <div className="flex justify-end gap-2 mt-4">
                <button type="button" onClick={() => setShowModal(false)} className="px-4 py-2 bg-gray-800 text-gray-300 rounded">Cancel</button>
                <button type="submit" className="px-4 py-2 bg-indigo-600 text-white rounded">Register</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default EmployeeDirectory;