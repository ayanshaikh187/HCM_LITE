import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const Setup = () => {
  const [formData, setFormData] = useState({
    companyName: '',
    adminName: '',
    adminEmail: '',
    adminPassword: '',
    officeStartTime: '09:00',
    graceTimeMinutes: 15,
  });
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await axios.post('http://localhost:5000/api/setup/init', formData);
      alert('Setup successful! Please login with your Admin credentials.');
      navigate('/login');
    } catch (err) {
      alert(err.response?.data?.message || 'Setup failed.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-950 flex items-center justify-center p-4">
      <div className="max-w-xl w-full bg-gray-900 border border-gray-800 rounded-xl p-8 shadow-2xl">
        <h2 className="text-2xl font-bold text-white mb-2">HCM Lite First-Run Setup</h2>
        <p className="text-gray-400 text-sm mb-6">Initialize your company profile and primary Admin account.</p>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="text-gray-300 text-sm font-medium">Company Name</label>
            <input
              type="text" required
              value={formData.companyName}
              onChange={(e) => setFormData({ ...formData, companyName: e.target.value })}
              className="w-full mt-1 px-4 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white"
              placeholder="Saylani Tech"
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-gray-300 text-sm font-medium">Admin Full Name</label>
              <input
                type="text" required
                value={formData.adminName}
                onChange={(e) => setFormData({ ...formData, adminName: e.target.value })}
                className="w-full mt-1 px-4 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white"
              />
            </div>
            <div>
              <label className="text-gray-300 text-sm font-medium">Admin Email</label>
              <input
                type="email" required
                value={formData.adminEmail}
                onChange={(e) => setFormData({ ...formData, adminEmail: e.target.value })}
                className="w-full mt-1 px-4 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white"
              />
            </div>
          </div>
          <div>
            <label className="text-gray-300 text-sm font-medium">Admin Password</label>
            <input
              type="password" required
              value={formData.adminPassword}
              onChange={(e) => setFormData({ ...formData, adminPassword: e.target.value })}
              className="w-full mt-1 px-4 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white"
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-gray-300 text-sm font-medium">Office Start Time</label>
              <input
                type="time" required
                value={formData.officeStartTime}
                onChange={(e) => setFormData({ ...formData, officeStartTime: e.target.value })}
                className="w-full mt-1 px-4 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white"
              />
            </div>
            <div>
              <label className="text-gray-300 text-sm font-medium">Grace Time (Minutes)</label>
              <input
                type="number" required
                value={formData.graceTimeMinutes}
                onChange={(e) => setFormData({ ...formData, graceTimeMinutes: e.target.value })}
                className="w-full mt-1 px-4 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white"
              />
            </div>
          </div>
          <button
            type="submit" disabled={loading}
            className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-lg mt-4 transition"
          >
            {loading ? 'Initializing...' : 'Initialize System'}
          </button>
        </form>
      </div>
    </div>
  );
};

export default Setup;