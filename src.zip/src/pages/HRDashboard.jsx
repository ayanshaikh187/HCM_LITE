import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const HRDashboard = () => {
  const [stats, setStats] = useState({
    presentToday: 0,
    onLeave: 0,
    lateToday: 0,
    pendingLeaves: 0,
  });
  const [recentLeaves, setRecentLeaves] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    fetchHRData();
  }, []);

  const fetchHRData = async () => {
    try {
      const token = localStorage.getItem('token');
      const config = {
        headers: { Authorization: `Bearer ${token}` },
      };

      // Fetch HR metrics and pending leave requests from backend APIs
      // (Ensure your backend has matching endpoints: /api/hr/metrics & /api/hr/leaves/pending)
      const resStats = await axios.get('http://localhost:5000/api/hr/metrics', config);
      const resLeaves = await axios.get('http://localhost:5000/api/hr/leaves/pending', config);

      setStats(resStats.data);
      setRecentLeaves(resLeaves.data);
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to load HR dashboard data.');
    } finally {
      setLoading(false);
    }
  };

  const handleLeaveAction = async (leaveId, status) => {
    try {
      const token = localStorage.getItem('token');
      await axios.patch(
        `http://localhost:5000/api/hr/leaves/${leaveId}`,
        { status },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      // Refresh pending leaves list
      setRecentLeaves(recentLeaves.filter((leave) => leave._id !== leaveId));
    } catch (err) {
      alert(err.response?.data?.message || 'Failed to update leave status.');
    }
  };

  const handleLogout = () => {
    localStorage.clear();
    navigate('/login');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center text-white">
        Loading HR Dashboard...
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900 text-gray-100 flex">
      {/* Sidebar */}
      <aside className="w-64 bg-gray-800 border-r border-gray-700 hidden md:block p-6">
        <h1 className="text-2xl font-bold text-indigo-400 mb-8">HCM Lite HR</h1>
        <nav className="space-y-4">
          <a href="/hr/dashboard" className="block py-2.5 px-4 rounded bg-indigo-600 text-white font-medium">Dashboard</a>
          <a href="/hr/employees" className="block py-2.5 px-4 rounded hover:bg-gray-700 text-gray-300">Manage Employees</a>
          <a href="/hr/attendance" className="block py-2.5 px-4 rounded hover:bg-gray-700 text-gray-300">Attendance Board</a>
          <a href="/hr/leaves" className="block py-2.5 px-4 rounded hover:bg-gray-700 text-gray-300">Leave Approvals</a>
          <a href="/hr/payroll" className="block py-2.5 px-4 rounded hover:bg-gray-700 text-gray-300">Payroll Draft</a>
        </nav>
        <div className="mt-20">
          <button
            onClick={handleLogout}
            className="w-full py-2 bg-red-600 hover:bg-red-700 rounded text-white font-semibold transition"
          >
            Logout
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 p-8 overflow-y-auto">
        <header className="flex justify-between items-center mb-8 pb-4 border-b border-gray-800">
          <h2 className="text-3xl font-bold">HR People Operations</h2>
          <span className="text-sm bg-indigo-500/10 border border-indigo-500 text-indigo-400 px-3 py-1 rounded-full">
            Role: HR
          </span>
        </header>

        {error && (
          <div className="mb-6 bg-red-500/10 border border-red-500 text-red-400 px-4 py-3 rounded text-sm">
            {error}
          </div>
        )}

        {/* KPI Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-gray-800 border border-gray-700 rounded-lg p-6 shadow">
            <p className="text-gray-400 text-sm font-medium">Present Today</p>
            <h3 className="text-3xl font-bold text-white mt-2">{stats.presentToday}</h3>
          </div>
          <div className="bg-gray-800 border border-gray-700 rounded-lg p-6 shadow">
            <p className="text-gray-400 text-sm font-medium">On Leave</p>
            <h3 className="text-3xl font-bold text-white mt-2">{stats.onLeave}</h3>
          </div>
          <div className="bg-gray-800 border border-gray-700 rounded-lg p-6 shadow">
            <p className="text-gray-400 text-sm font-medium">Late Corners</p>
            <h3 className="text-3xl font-bold text-white mt-2">{stats.lateToday}</h3>
          </div>
          <div className="bg-gray-800 border border-gray-700 rounded-lg p-6 shadow">
            <p className="text-gray-400 text-sm font-medium">Pending Approvals</p>
            <h3 className="text-3xl font-bold text-white mt-2">{stats.pendingLeaves}</h3>
          </div>
        </div>

        {/* Pending Leave Requests Section */}
        <div className="bg-gray-800 border border-gray-700 rounded-lg p-6 shadow">
          <h3 className="text-xl font-semibold mb-4 text-white">Pending Leave Requests Inbox</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-gray-700 text-gray-400 text-sm">
                  <th className="py-3 px-4">Employee</th>
                  <th className="py-3 px-4">Leave Type</th>
                  <th className="py-3 px-4">Dates</th>
                  <th className="py-3 px-4">Reason</th>
                  <th className="py-3 px-4 text-center">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-700 text-sm">
                {recentLeaves.length > 0 ? (
                  recentLeaves.map((leave) => (
                    <tr key={leave._id} className="hover:bg-gray-750">
                      <td className="py-3 px-4 text-indigo-300 font-medium">{leave.employeeName}</td>
                      <td className="py-3 px-4">{leave.leaveType}</td>
                      <td className="py-3 px-4 text-gray-300">
                        {new Date(leave.startDate).toLocaleDateString()} - {new Date(leave.endDate).toLocaleDateString()}
                      </td>
                      <td className="py-3 px-4 text-gray-400 max-w-xs truncate">{leave.reason}</td>
                      <td className="py-3 px-4 text-center space-x-2">
                        <button
                          onClick={() => handleLeaveAction(leave._id, 'Approved')}
                          className="px-3 py-1 bg-green-600 hover:bg-green-700 text-white rounded text-xs font-semibold"
                        >
                          Approve
                        </button>
                        <button
                          onClick={() => handleLeaveAction(leave._id, 'Rejected')}
                          className="px-3 py-1 bg-red-600 hover:bg-red-700 text-white rounded text-xs font-semibold"
                        >
                          Reject
                        </button>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="5" className="py-4 text-center text-gray-500">
                      No pending leave requests.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </main>
    </div>
  );
};

export default HRDashboard;