import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const EmployeeDashboard = () => {
  const [stats, setStats] = useState({
    hoursThisWeek: 0,
    lateCount: 0,
    leaveBalance: 0,
    lastPayslip: null,
  });
  const [isCheckedIn, setIsCheckedIn] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    fetchEmployeeData();
  }, []);

  const fetchEmployeeData = async () => {
    try {
      const token = localStorage.getItem('token');
      const config = {
        headers: { Authorization: `Bearer ${token}` },
      };

      // Fetch employee personal stats from backend APIs
      // (Ensure your backend has matching endpoints: /api/employee/metrics)
      const res = await axios.get('http://localhost:5000/api/employee/metrics', config);
      setStats(res.data);
      setIsCheckedIn(res.data.isCheckedIn || false);
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to load employee dashboard data.');
    } finally {
      setLoading(false);
    }
  };

  const handleCheckInOut = async () => {
    try {
      const token = localStorage.getItem('token');
      const endpoint = isCheckedIn ? 'checkout' : 'checkin';
      const res = await axios.post(
        `http://localhost:5000/api/attendance/${endpoint}`,
        {},
        { headers: { Authorization: `Bearer ${token}` } }
      );

      setIsCheckedIn(!isCheckedIn);
      alert(res.data.message || (isCheckedIn ? 'Checked out successfully!' : 'Checked in successfully!'));
      fetchEmployeeData();
    } catch (err) {
      alert(err.response?.data?.message || 'Attendance action failed.');
    }
  };

  const handleLogout = () => {
    localStorage.clear();
    navigate('/login');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center text-white">
        Loading Employee Dashboard...
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900 text-gray-100 flex">
      {/* Sidebar */}
      <aside className="w-64 bg-gray-800 border-r border-gray-700 hidden md:block p-6">
        <h1 className="text-2xl font-bold text-indigo-400 mb-8">HCM Lite Portal</h1>
        <nav className="space-y-4">
          <a href="/employee/dashboard" className="block py-2.5 px-4 rounded bg-indigo-600 text-white font-medium">Dashboard</a>
          <a href="/employee/attendance" className="block py-2.5 px-4 rounded hover:bg-gray-700 text-gray-300">My Attendance</a>
          <a href="/employee/leave" className="block py-2.5 px-4 rounded hover:bg-gray-700 text-gray-300">Apply Leave</a>
          <a href="/employee/payslips" className="block py-2.5 px-4 rounded hover:bg-gray-700 text-gray-300">My Payslips</a>
          <a href="/employee/profile" className="block py-2.5 px-4 rounded hover:bg-gray-700 text-gray-300">My Profile</a>
        </nav>
        <div className="mt-20">
          <button
            onClick={handleLogout}
            className="w-full py-2 bg-red-600 hover:bg-red-700 rounded text-white font-semibold transition"
          >
            Logout
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 p-8 overflow-y-auto">
        <header className="flex justify-between items-center mb-8 pb-4 border-b border-gray-800">
          <h2 className="text-3xl font-bold">Employee Self-Service</h2>
          <span className="text-sm bg-indigo-500/10 border border-indigo-500 text-indigo-400 px-3 py-1 rounded-full">
            Role: Employee
          </span>
        </header>

        {error && (
          <div className="mb-6 bg-red-500/10 border border-red-500 text-red-400 px-4 py-3 rounded text-sm">
            {error}
          </div>
        )}

        {/* Check-In / Check-Out Widget Section */}
        <div className="bg-gray-800 border border-gray-700 rounded-lg p-6 shadow mb-8 flex justify-between items-center">
          <div>
            <h3 className="text-xl font-semibold text-white">Daily Attendance Widget</h3>
            <p className="text-gray-400 text-sm mt-1">Mark your daily office check-in and check-out time.</p>
          </div>
          <button
            onClick={handleCheckInOut}
            className={`px-6 py-3 rounded-lg font-semibold text-white transition ${
              isCheckedIn ? 'bg-amber-600 hover:bg-amber-700' : 'bg-green-600 hover:bg-green-700'
            }`}
          >
            {isCheckedIn ? 'Check Out' : 'Check In Now'}
          </button>
        </div>

        {/* KPI Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-gray-800 border border-gray-700 rounded-lg p-6 shadow">
            <p className="text-gray-400 text-sm font-medium">Hours This Week</p>
            <h3 className="text-3xl font-bold text-white mt-2">{stats.hoursThisWeek} / 40h</h3>
          </div>
          <div className="bg-gray-800 border border-gray-700 rounded-lg p-6 shadow">
            <p className="text-gray-400 text-sm font-medium">Late Count</p>
            <h3 className="text-3xl font-bold text-white mt-2">{stats.lateCount}</h3>
          </div>
          <div className="bg-gray-800 border border-gray-700 rounded-lg p-6 shadow">
            <p className="text-gray-400 text-sm font-medium">Leave Balance Left</p>
            <h3 className="text-3xl font-bold text-white mt-2">{stats.leaveBalance} Days</h3>
          </div>
          <div className="bg-gray-800 border border-gray-700 rounded-lg p-6 shadow">
            <p className="text-gray-400 text-sm font-medium">Last Payslip</p>
            <h3 className="text-xl font-bold text-indigo-300 mt-3">
              {stats.lastPayslip ? (
                <a href={stats.lastPayslip} target="_blank" rel="noopener noreferrer" className="underline hover:text-indigo-400">
                  Download PDF
                </a>
              ) : (
                'Not Available'
              )}
            </h3>
          </div>
        </div>
      </main>
    </div>
  );
};

export default EmployeeDashboard;