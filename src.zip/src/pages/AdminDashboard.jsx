import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const AdminDashboard = () => {
  const [stats, setStats] = useState({
    headcount: 0,
    attrition: '0%',
    payrollCost: '$0',
    avgSalary: '$0',
  });
  const [auditLogs, setAuditLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    fetchAdminData();
  }, []);

  const fetchAdminData = async () => {
    try {
      const token = localStorage.getItem('token');
      const config = {
        headers: { Authorization: `Bearer ${token}` },
      };

      // Fetch admin metrics and audit logs from backend APIs
      // (Ensure your backend has matching endpoints: /api/admin/metrics & /api/admin/audit-logs)
      const resStats = await axios.get('http://localhost:5000/api/admin/metrics', config);
      const resAudit = await axios.get('http://localhost:5000/api/admin/audit-logs', config);

      setStats(resStats.data);
      setAuditLogs(resAudit.data);
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to load admin dashboard data.');
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = () => {
    localStorage.clear();
    navigate('/login');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center text-white">
        Loading Admin Dashboard...
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900 text-gray-100 flex">
      {/* Sidebar */}
      <aside className="w-64 bg-gray-800 border-r border-gray-700 hidden md:block p-6">
        <h1 className="text-2xl font-bold text-indigo-400 mb-8">HCM Lite Admin</h1>
        <nav className="space-y-4">
          <a href="/admin/dashboard" className="block py-2.5 px-4 rounded bg-indigo-600 text-white font-medium">Dashboard</a>
          <a href="/admin/setup" className="block py-2.5 px-4 rounded hover:bg-gray-700 text-gray-300">Company Setup</a>
          <a href="/admin/hr-management" className="block py-2.5 px-4 rounded hover:bg-gray-700 text-gray-300">Manage HR Logins</a>
          <a href="/admin/payroll-finalize" className="block py-2.5 px-4 rounded hover:bg-gray-700 text-gray-300">Finalize Payroll</a>
          <a href="/admin/audit-logs" className="block py-2.5 px-4 rounded hover:bg-gray-700 text-gray-300">Audit Logs</a>
        </nav>
        <div className="mt-20">
          <button
            onClick={handleLogout}
            className="w-full py-2 bg-red-600 hover:bg-red-700 rounded text-white font-semibold transition"
          >
            Logout
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 p-8 overflow-y-auto">
        <header className="flex justify-between items-center mb-8 pb-4 border-b border-gray-800">
          <h2 className="text-3xl font-bold">Company Overview Dashboard</h2>
          <span className="text-sm bg-indigo-500/10 border border-indigo-500 text-indigo-400 px-3 py-1 rounded-full">
            Role: Admin
          </span>
        </header>

        {error && (
          <div className="mb-6 bg-red-500/10 border border-red-500 text-red-400 px-4 py-3 rounded text-sm">
            {error}
          </div>
        )}

        {/* KPI Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-gray-800 border border-gray-700 rounded-lg p-6 shadow">
            <p className="text-gray-400 text-sm font-medium">Active Headcount</p>
            <h3 className="text-3xl font-bold text-white mt-2">{stats.headcount}</h3>
          </div>
          <div className="bg-gray-800 border border-gray-700 rounded-lg p-6 shadow">
            <p className="text-gray-400 text-sm font-medium">YTD Attrition</p>
            <h3 className="text-3xl font-bold text-white mt-2">{stats.attrition}</h3>
          </div>
          <div className="bg-gray-800 border border-gray-700 rounded-lg p-6 shadow">
            <p className="text-gray-400 text-sm font-medium">Total Payroll Cost</p>
            <h3 className="text-3xl font-bold text-white mt-2">{stats.payrollCost}</h3>
          </div>
          <div className="bg-gray-800 border border-gray-700 rounded-lg p-6 shadow">
            <p className="text-gray-400 text-sm font-medium">Average Salary</p>
            <h3 className="text-3xl font-bold text-white mt-2">{stats.avgSalary}</h3>
          </div>
        </div>

        {/* Recent Audit Feed Section */}
        <div className="bg-gray-800 border border-gray-700 rounded-lg p-6 shadow">
          <h3 className="text-xl font-semibold mb-4 text-white">System Audit Feed</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-gray-700 text-gray-400 text-sm">
                  <th className="py-3 px-4">Actor</th>
                  <th className="py-3 px-4">Action</th>
                  <th className="py-3 px-4">Entity</th>
                  <th className="py-3 px-4">Timestamp</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-700 text-sm">
                {auditLogs.length > 0 ? (
                  auditLogs.map((log, index) => (
                    <tr key={index} className="hover:bg-gray-750">
                      <td className="py-3 px-4 text-indigo-300">{log.actor}</td>
                      <td className="py-3 px-4">{log.action}</td>
                      <td className="py-3 px-4 text-gray-300">{log.entity}</td>
                      <td className="py-3 px-4 text-gray-400">{new Date(log.timestamp).toLocaleString()}</td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="4" className="py-4 text-center text-gray-500">
                      No audit logs found yet.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </main>
    </div>
  );
};

export default AdminDashboard;