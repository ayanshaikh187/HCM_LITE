import React, { useState } from 'react';
import axios from 'axios';

const LeaveManagement = () => {
  const [smartPrompt, setSmartPrompt] = useState('');
  const [leaveForm, setLeaveForm] = useState({ leaveType: 'Casual', startDate: '', endDate: '', reason: '' });
  const [loading, setLoading] = useState(false);

  const handleSmartFill = async () => {
    if (!smartPrompt.trim()) return;
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      const res = await axios.post('http://localhost:5000/api/ai/smart-leave', { prompt: smartPrompt }, {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.data) {
        setLeaveForm(res.data);
      }
    } catch (err) {
      alert('Failed to extract leave details from text.');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmitLeave = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem('token');
      await axios.post('http://localhost:5000/api/leaves', leaveForm, {
        headers: { Authorization: `Bearer ${token}` }
      });
      alert('Leave request submitted successfully!');
    } catch (err) {
      alert(err.response?.data?.message || 'Error submitting leave.');
    }
  };

  return (
    <div className="p-8 bg-gray-950 text-white min-h-screen max-w-4xl mx-auto">
      <h2 className="text-3xl font-bold mb-6">Apply for Leave</h2>

      {/* Smart Leave AI Input */}
      <div className="bg-indigo-950/40 border border-indigo-800/60 p-6 rounded-xl mb-8">
        <h3 className="text-lg font-semibold text-indigo-300 mb-2">✨ Smart Leave AI Assistant</h3>
        <p className="text-sm text-gray-400 mb-4">Type your request in plain words (e.g., "Need next Monday and Tuesday off for a wedding")</p>
        <div className="flex gap-2">
          <input
            type="text"
            value={smartPrompt}
            onChange={(e) => setSmartPrompt(e.target.value)}
            placeholder="Type your leave request here..."
            className="flex-1 p-3 bg-gray-900 border border-gray-800 rounded-lg text-white"
          />
          <button
            onClick={handleSmartFill} disabled={loading}
            className="px-5 py-3 bg-indigo-600 hover:bg-indigo-700 rounded-lg font-medium text-white transition"
          >
            {loading ? 'Processing...' : 'Auto-Fill Form'}
          </button>
        </div>
      </div>

      {/* Manual / Auto-filled Form */}
      <form onSubmit={handleSubmitLeave} className="bg-gray-900 border border-gray-800 p-6 rounded-xl space-y-4">
        <div>
          <label className="block text-gray-300 text-sm mb-1">Leave Type</label>
          <select
            value={leaveForm.leaveType}
            onChange={(e) => setLeaveForm({ ...leaveForm, leaveType: e.target.value })}
            className="w-full p-2 bg-gray-800 border border-gray-700 rounded text-white"
          >
            <option value="Casual">Casual</option>
            <option value="Sick">Sick</option>
            <option value="Annual">Annual</option>
            <option value="Unpaid">Unpaid</option>
          </select>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-gray-300 text-sm mb-1">Start Date</label>
            <input
              type="date" required
              value={leaveForm.startDate}
              onChange={(e) => setLeaveForm({ ...leaveForm, startDate: e.target.value })}
              className="w-full p-2 bg-gray-800 border border-gray-700 rounded text-white"
            />
          </div>
          <div>
            <label className="block text-gray-300 text-sm mb-1">End Date</label>
            <input
              type="date" required
              value={leaveForm.endDate}
              onChange={(e) => setLeaveForm({ ...leaveForm, endDate: e.target.value })}
              className="w-full p-2 bg-gray-800 border border-gray-700 rounded text-white"
            />
          </div>
        </div>
        <div>
          <label className="block text-gray-300 text-sm mb-1">Reason</label>
          <textarea
            required rows="3"
            value={leaveForm.reason}
            onChange={(e) => setLeaveForm({ ...leaveForm, reason: e.target.value })}
            className="w-full p-2 bg-gray-800 border border-gray-700 rounded text-white"
          ></textarea>
        </div>
        <button type="submit" className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 font-semibold rounded-lg text-white">
          Submit Leave Application
        </button>
      </form>
    </div>
  );
};

export default LeaveManagement;