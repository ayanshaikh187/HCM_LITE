import React, { useState, useEffect } from 'react';
import axios from 'axios';

const AuditLogs = () => {
  const [logs, setLogs] = useState([]);
  const [announcements, setAnnouncements] = useState([]);
  const [newAnnouncement, setNewAnnouncement] = useState('');
  const user = JSON.parse(localStorage.getItem('user') || '{}');

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const token = localStorage.getItem('token');
      const config = { headers: { Authorization: `Bearer ${token}` } };
      
      const resAnn = await axios.get('http://localhost:5000/api/comms/announcements', config);
      setAnnouncements(resAnn.data || []);

      if (user.role === 'Admin') {
        const resLogs = await axios.get('http://localhost:5000/api/admin/audit-logs', config);
        setLogs(resLogs.data || []);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handlePostAnnouncement = async (e) => {
    e.preventDefault();
    if (!newAnnouncement.trim()) return;
    try {
      const token = localStorage.getItem('token');
      await axios.post(
        'http://localhost:5000/api/comms/announcements',
        { title: newAnnouncement },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setNewAnnouncement('');
      fetchData();
    } catch (err) {
      alert('Failed to post announcement');
    }
  };

  return (
    <div className="p-8 bg-gray-950 text-white min-h-screen max-w-6xl mx-auto space-y-8">
      {/* Announcements Section */}
      <div className="bg-gray-900 border border-gray-800 rounded-xl p-6 shadow-xl">
        <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
          📢 Company Announcements
        </h2>

        {(user.role === 'Admin' || user.role === 'HR') && (
          <form onSubmit={handlePostAnnouncement} className="flex gap-3 mb-6">
            <input
              type="text"
              value={newAnnouncement}
              onChange={(e) => setNewAnnouncement(e.target.value)}
              placeholder="Post a company-wide announcement..."
              className="flex-1 px-4 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm"
            />
            <button type="submit" className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-lg text-sm">
              Post
            </button>
          </form>
        )}

        <div className="space-y-3">
          {announcements.map((item, idx) => (
            <div key={idx} className="p-4 bg-gray-850 border border-gray-800 rounded-lg text-sm flex justify-between">
              <span className="text-gray-200">{item.title}</span>
              <span className="text-xs text-gray-500">{new Date(item.createdAt).toLocaleDateString()}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Audit Log Table (Admin Only) */}
      {user.role === 'Admin' && (
        <div className="bg-gray-900 border border-gray-800 rounded-xl p-6 shadow-xl">
          <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
            🛡️ System Audit Logs
          </h2>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead className="bg-gray-850 text-gray-400 border-b border-gray-800 text-sm">
                <tr>
                  <th className="p-3">Actor</th>
                  <th className="p-3">Action</th>
                  <th className="p-3">Entity</th>
                  <th className="p-3">Timestamp</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-800 text-sm">
                {logs.map((log, idx) => (
                  <tr key={idx} className="hover:bg-gray-850">
                    <td className="p-3 font-medium text-indigo-300">{log.actor}</td>
                    <td className="p-3 text-gray-300">{log.action}</td>
                    <td className="p-3 text-gray-400">{log.entity}</td>
                    <td className="p-3 text-gray-500">{new Date(log.timestamp).toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};

export default AuditLogs;