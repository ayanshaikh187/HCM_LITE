import React, { useState } from 'react';
import axios from 'axios';

const PolicyQA = () => {
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState('');
  const [loading, setLoading] = useState(false);

  const handleAskPolicy = async (e) => {
    e.preventDefault();
    if (!question.trim()) return;

    setLoading(true);
    setAnswer('');

    try {
      const token = localStorage.getItem('token');
      const config = {
        headers: { Authorization: `Bearer ${token}` },
      };

      // Call backend AI policy Q&A endpoint
      const res = await axios.post(
        'http://localhost:5000/api/ai/policy-qa',
        { question },
        config
      );

      setAnswer(res.data.answer || 'No answer returned from policy database.');
    } catch (err) {
      setAnswer(err.response?.data?.message || 'Failed to fetch policy answer. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-8 bg-gray-950 text-white min-h-screen max-w-4xl mx-auto">
      <div className="mb-8">
        <h2 className="text-3xl font-bold">Company Policy Q&A</h2>
        <p className="text-gray-400 text-sm mt-1">
          Ask questions regarding office hours, leave quotas, grace time, and payroll rules.
        </p>
      </div>

      <div className="bg-gray-900 border border-gray-800 rounded-xl p-6 shadow-xl mb-8">
        <form onSubmit={handleAskPolicy} className="space-y-4">
          <div>
            <label className="block text-gray-300 text-sm font-medium mb-2">
              Your Question
            </label>
            <input
              type="text"
              required
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              placeholder="E.g., What is our annual leave quota? Or what are the office timings?"
              className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:outline-none focus:border-indigo-500"
            />
          </div>
          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-lg text-sm transition disabled:opacity-50"
          >
            {loading ? 'Searching Policies...' : 'Ask AI Policy Assistant'}
          </button>
        </form>
      </div>

      {answer && (
        <div className="bg-gray-900 border border-indigo-500/40 rounded-xl p-6 shadow-xl">
          <h3 className="text-lg font-semibold text-indigo-400 mb-2 flex items-center gap-2">
            <span>💡</span> Answer from Company Policy
          </h3>
          <p className="text-gray-300 text-sm leading-relaxed whitespace-pre-wrap">
            {answer}
          </p>
        </div>
      )}
    </div>
  );
};

export default PolicyQA;