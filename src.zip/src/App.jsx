import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Login from './pages/Login';
import Setup from './pages/Setup';
import AdminDashboard from './pages/AdminDashboard';
import HRDashboard from './pages/HRDashboard';
import EmployeeDashboard from './pages/EmployeeDashboard';
import EmployeeDirectory from './pages/EmployeeDirectory';
import AttendanceBoard from './pages/AttendanceBoard';
import LeaveManagement from './pages/LeaveManagement';
import PayrollManagement from './pages/PayrollManagement';
import PolicyQA from './pages/PolicyQa';
import AuditLogs from './pages/AuditLogs';

const ProtectedRoute = ({ children, allowedRoles }) => {
  const token = localStorage.getItem('token');
  const user = JSON.parse(localStorage.getItem('user') || '{}');

  if (!token) return <Navigate to="/login" replace />;
  if (allowedRoles && !allowedRoles.includes(user.role)) {
    return <Navigate to={`/${user.role?.toLowerCase()}/dashboard`} replace />;
  }
  return children;
};

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/setup" element={<Setup />} />

        {/* Admin Routes */}
        <Route path="/admin/dashboard" element={<ProtectedRoute allowedRoles={['Admin']}><AdminDashboard /></ProtectedRoute>} />
        <Route path="/admin/setup" element={<ProtectedRoute allowedRoles={['Admin']}><Setup /></ProtectedRoute>} />
        <Route path="/admin/hr-management" element={<ProtectedRoute allowedRoles={['Admin']}><EmployeeDirectory /></ProtectedRoute>} />
        <Route path="/admin/payroll-finalize" element={<ProtectedRoute allowedRoles={['Admin']}><PayrollManagement /></ProtectedRoute>} />
        <Route path="/admin/audit-logs" element={<ProtectedRoute allowedRoles={['Admin']}><AuditLogs /></ProtectedRoute>} />
        <Route path="/audit-logs" element={<ProtectedRoute allowedRoles={['Admin', 'HR']}><AuditLogs /></ProtectedRoute>} />
        
        {/* HR & Admin Shared */}
        <Route path="/hr/dashboard" element={<ProtectedRoute allowedRoles={['HR', 'Admin']}><HRDashboard /></ProtectedRoute>} />
        <Route path="/hr/employees" element={<ProtectedRoute allowedRoles={['HR', 'Admin']}><EmployeeDirectory /></ProtectedRoute>} />
        <Route path="/hr/attendance" element={<ProtectedRoute allowedRoles={['HR', 'Admin']}><AttendanceBoard /></ProtectedRoute>} />
        <Route path="/hr/leaves" element={<ProtectedRoute allowedRoles={['HR', 'Admin']}><HRDashboard /></ProtectedRoute>} />
        <Route path="/hr/payroll" element={<ProtectedRoute allowedRoles={['HR', 'Admin']}><PayrollManagement /></ProtectedRoute>} />
        <Route path="/employees" element={<ProtectedRoute allowedRoles={['HR', 'Admin']}><EmployeeDirectory /></ProtectedRoute>} />
        <Route path="/payroll" element={<ProtectedRoute allowedRoles={['HR', 'Admin']}><PayrollManagement /></ProtectedRoute>} />

        {/* Employee & Shared */}
        <Route path="/employee/dashboard" element={<ProtectedRoute allowedRoles={['Employee', 'HR', 'Admin']}><EmployeeDashboard /></ProtectedRoute>} />
        <Route path="/employee/attendance" element={<ProtectedRoute allowedRoles={['Employee', 'HR', 'Admin']}><AttendanceBoard /></ProtectedRoute>} />
        <Route path="/employee/leave" element={<ProtectedRoute allowedRoles={['Employee', 'HR', 'Admin']}><LeaveManagement /></ProtectedRoute>} />
        <Route path="/employee/payslips" element={<ProtectedRoute allowedRoles={['Employee', 'HR', 'Admin']}><PayrollManagement /></ProtectedRoute>} />
        <Route path="/employee/profile" element={<ProtectedRoute allowedRoles={['Employee', 'HR', 'Admin']}><PolicyQA /></ProtectedRoute>} />
        <Route path="/attendance" element={<ProtectedRoute allowedRoles={['Employee', 'HR', 'Admin']}><AttendanceBoard /></ProtectedRoute>} />
        <Route path="/leave" element={<ProtectedRoute allowedRoles={['Employee', 'HR', 'Admin']}><LeaveManagement /></ProtectedRoute>} />
        <Route path="/policy-qa" element={<ProtectedRoute allowedRoles={['Employee', 'HR', 'Admin']}><PolicyQA /></ProtectedRoute>} />

        <Route path="*" element={<Navigate to="/login" replace />} />
      </Routes>
    </Router>
  );
}

export default App;