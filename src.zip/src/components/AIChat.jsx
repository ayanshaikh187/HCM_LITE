import React, { useState } from 'react';
import axios from 'axios';

const AIChat = () => {
  const [messages, setMessages] = useState([
    { sender: 'ai', text: 'Hello! I am your HCM AI Assistant. Ask me anything about attendance, leave balances, headcount, or company policies.' }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSendMessage = async (e) => {
    e.preventDefault();
    if (!input.trim()) return;

    const userMessage = input;
    setMessages((prev) => [...prev, { sender: 'user', text: userMessage }]);
    setInput('');
    setLoading(true);

    try {
      const token = localStorage.getItem('token');
      const config = {
        headers: { Authorization: `Bearer ${token}` },
      };

      // Call backend AI chat endpoint
      const response = await axios.post(
        'http://localhost:5000/api/ai/chat',
        { prompt: userMessage },
        config
      );

      const aiReply = response.data.reply || 'Here is the information you requested.';
      setMessages((prev) => [...prev, { sender: 'ai', text: aiReply }]);
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        { sender: 'ai', text: 'Sorry, I encountered an error answering your request. Please try again.' }
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-gray-800 border border-gray-700 rounded-lg shadow-lg flex flex-col h-[500px] w-full max-w-2xl mx-auto">
      {/* Chat Header */}
      <div className="px-6 py-4 border-b border-gray-700 flex justify-between items-center bg-gray-850 rounded-t-lg">
        <h3 className="text-lg font-semibold text-white flex items-center gap-2">
          <span>🤖</span> HCM AI Assistant
        </h3>
        <span className="text-xs bg-indigo-500/10 border border-indigo-500 text-indigo-400 px-2.5 py-1 rounded-full">
          AI-Generated
        </span>
      </div>

      {/* Messages Container */}
      <div className="flex-1 p-6 overflow-y-auto space-y-4">
        {messages.map((msg, index) => (
          <div
            key={index}
            className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-md px-4 py-3 rounded-lg text-sm leading-relaxed ${
                msg.sender === 'user'
                  ? 'bg-indigo-600 text-white rounded-br-none'
                  : 'bg-gray-700 text-gray-200 rounded-bl-none border border-gray-600'
              }`}
            >
              {msg.text}
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex justify-start">
            <div className="bg-gray-700 text-gray-400 px-4 py-3 rounded-lg text-sm rounded-bl-none border border-gray-600 animate-pulse">
              AI is thinking...
            </div>
          </div>
        )}
      </div>

      {/* Input Form */}
      <form onSubmit={handleSendMessage} className="p-4 border-t border-gray-700 flex gap-2 bg-gray-850 rounded-b-lg">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask e.g., 'Who is on leave today?' or 'How many sick leaves do I have?'..."
          className="flex-1 px-4 py-2 bg-gray-900 border border-gray-700 rounded-lg text-white text-sm focus:outline-none focus:border-indigo-500"
        />
        <button
          type="submit"
          disabled={loading}
          className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-lg text-sm transition disabled:opacity-50"
        >
          Send
        </button>
      </form>
    </div>
  );
};

export default AIChat;