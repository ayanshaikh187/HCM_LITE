const User = require('../models/User');
const { logAudit } = require('../middleware/audit');

// GET /api/employees?search=&department=
exports.getEmployees = async (req, res) => {
  try {
    const { search, department } = req.query;
    let filter = {};

    if (search) {
      filter.$or = [
        { name: { $regex: search, $options: 'i' } },
        { email: { $regex: search, $options: 'i' } }
      ];
    }
    if (department) filter.department = department;

    const employees = await User.find(filter).select('-password');
    res.json(employees);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// POST /api/employees (Admin/HR only)
exports.createEmployee = async (req, res) => {
  try {
    const { name, email, password, role, department, designation, basicSalary } = req.body;

    if (!name || !email) {
      return res.status(400).json({ message: 'Name and email are required' });
    }

    const normalizedEmail = email.trim().toLowerCase();
    const existing = await User.findOne({ email: normalizedEmail });
    if (existing) return res.status(400).json({ message: 'Email already exists' });

    const empPassword = password || 'Welcome123!';

    const employee = await User.create({
      name: name.trim(),
      email: normalizedEmail,
      password: empPassword,
      role: role || 'Employee',
      department: department || '',
      designation: designation || '',
      basicSalary: Number(basicSalary) || 0
    });

    await logAudit(req.user.email, 'Employee created', `Employee: ${name} (${normalizedEmail})`);

    const empResponse = employee.toObject();
    delete empResponse.password;
    res.status(201).json(empResponse);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};