const User = require('../models/User');
const Attendance = require('../models/Attendance');
const Leave = require('../models/Leave');
const Payroll = require('../models/Payroll');
const AuditLog = require('../models/Auditlog');
const Announcement = require('../models/Announcement');
const moment = require('moment');

// GET /api/admin/metrics
exports.adminMetrics = async (req, res) => {
  try {
    const totalEmployees = await User.countDocuments({ role: { $ne: 'Admin' } });
    const avgSalary = await User.aggregate([
      { $match: { role: { $ne: 'Admin' } } },
      { $group: { _id: null, avg: { $avg: '$basicSalary' } } }
    ]);
    const lastMonth = moment().subtract(1, 'month').format('YYYY-MM');
    const payrollCost = await Payroll.aggregate([
      { $match: { month: lastMonth, isLocked: true } },
      { $group: { _id: null, total: { $sum: '$netSalary' } } }
    ]);

    const avg = avgSalary[0]?.avg ? Math.round(avgSalary[0].avg) : 0;
    const total = payrollCost[0]?.total ? Math.round(payrollCost[0].total) : 0;

    res.json({
      headcount: totalEmployees,
      averageSalary: avg,
      avgSalary: `$${avg}`,
      lastMonthPayrollCost: total,
      payrollCost: `$${total}`,
      attrition: '0%'
    });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// GET /api/hr/metrics
exports.hrMetrics = async (req, res) => {
  try {
    const today = moment().format('YYYY-MM-DD');
    const presentToday = await Attendance.countDocuments({ date: today, status: 'Present' });
    const lateToday = await Attendance.countDocuments({ date: today, status: 'Late' });
    const onLeave = await Leave.countDocuments({
      status: 'Approved',
      startDate: { $lte: new Date() },
      endDate: { $gte: new Date() }
    });
    const pendingApprovals = await Leave.countDocuments({ status: 'Pending' });

    res.json({
      presentToday,
      lateToday,
      onLeave,
      pendingApprovals,
      pendingLeaves: pendingApprovals
    });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// GET /api/employee/metrics
exports.employeeMetrics = async (req, res) => {
  try {
    const userId = req.user.id;
    const user = await User.findById(userId);

    const startOfMonth = moment().startOf('month').format('YYYY-MM-DD');
    const endOfMonth = moment().endOf('month').format('YYYY-MM-DD');
    const lateCount = await Attendance.countDocuments({
      employeeId: userId,
      date: { $gte: startOfMonth, $lte: endOfMonth },
      status: 'Late'
    });

    const startOfWeek = moment().startOf('week').format('YYYY-MM-DD');
    const weeklyAttendances = await Attendance.find({
      employeeId: userId,
      date: { $gte: startOfWeek }
    });
    const hoursThisWeek = weeklyAttendances.length * 8;

    const leavesTaken = await Leave.countDocuments({
      employeeId: userId,
      status: 'Approved'
    });
    const leaveBalance = Math.max(0, 24 - leavesTaken);

    const lastPayroll = await Payroll.findOne({ employeeId: userId }).sort({ createdAt: -1 });
    const lastPayslip = lastPayroll ? `http://localhost:5000/api/payroll/payslip/${lastPayroll._id}` : null;

    res.json({
      hoursThisWeek,
      lateCount,
      leaveBalance,
      lastPayslip,
      isCheckedIn: user?.isCheckedIn || false
    });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// GET /api/admin/audit-logs
exports.getAuditLogs = async (req, res) => {
  try {
    const logs = await AuditLog.find().sort({ timestamp: -1 }).limit(100);
    res.json(logs);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// GET /api/comms/announcements
exports.getAnnouncements = async (req, res) => {
  try {
    const announcements = await Announcement.find().sort({ createdAt: -1 });
    res.json(announcements);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// POST /api/comms/announcements
exports.createAnnouncement = async (req, res) => {
  try {
    const { title } = req.body;
    const announcement = await Announcement.create({ title });
    res.status(201).json(announcement);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};