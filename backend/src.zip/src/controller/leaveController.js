const Leave = require('../models/Leave');
const { logAudit } = require('../middleware/audit');

// GET /api/leaves - Get leaves (for current employee or all if HR/Admin)
exports.getLeaves = async (req, res) => {
  try {
    let filter = {};
    if (req.user.role === 'Employee') {
      filter.employeeId = req.user.id;
    }
    const leaves = await Leave.find(filter).sort({ createdAt: -1 });
    res.json(leaves);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// POST /api/leaves
exports.applyLeave = async (req, res) => {
  try {
    const { leaveType, startDate, endDate, reason } = req.body;
    if (!leaveType || !startDate || !endDate || !reason) {
      return res.status(400).json({ message: 'leaveType, startDate, endDate, and reason are required' });
    }

    const leave = await Leave.create({
      employeeId: req.user.id,
      employeeName: req.user.name,
      leaveType,
      startDate: new Date(startDate),
      endDate: new Date(endDate),
      reason
    });
    await logAudit(req.user.email, 'Leave applied', `Type: ${leaveType}, Dates: ${startDate} to ${endDate}`);
    res.status(201).json(leave);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// GET /api/hr/leaves/pending
exports.getPendingLeaves = async (req, res) => {
  try {
    const leaves = await Leave.find({ status: 'Pending' }).sort({ createdAt: -1 });
    res.json(leaves);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// PATCH /api/hr/leaves/:id
exports.updateLeaveStatus = async (req, res) => {
  try {
    const { status } = req.body; // 'Approved' or 'Rejected'
    if (!['Approved', 'Rejected'].includes(status)) {
      return res.status(400).json({ message: 'Invalid status' });
    }
    const leave = await Leave.findByIdAndUpdate(
      req.params.id,
      { status },
      { new: true }
    );
    if (!leave) return res.status(404).json({ message: 'Leave not found' });

    await logAudit(req.user.email, `Leave ${status}`, `For: ${leave.employeeName}`);
    res.json(leave);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};