const Attendance = require('../models/Attendance');
const User = require('../models/User');
const moment = require('moment');

// POST /api/attendance/check-in
exports.checkIn = async (req, res) => {
  try {
    const today = moment().format('YYYY-MM-DD');
    const now = moment().format('HH:mm:ss');
    const lateThreshold = '09:15:00'; // 9:15 AM ke baad Late

    const existing = await Attendance.findOne({
      employeeId: req.user.id,
      date: today
    });
    if (existing) return res.status(400).json({ message: 'Already checked in today' });

    const status = now > lateThreshold ? 'Late' : 'Present';

    const attendance = await Attendance.create({
      employeeId: req.user.id,
      employeeName: req.user.name,
      date: today,
      checkIn: now,
      status
    });

    // Update user's isCheckedIn flag
    await User.findByIdAndUpdate(req.user.id, { isCheckedIn: true });

    res.json({ message: 'Checked in', attendance });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// POST /api/attendance/check-out
exports.checkOut = async (req, res) => {
  try {
    const today = moment().format('YYYY-MM-DD');
    const now = moment().format('HH:mm:ss');

    const attendance = await Attendance.findOne({
      employeeId: req.user.id,
      date: today
    });
    if (!attendance) return res.status(400).json({ message: 'No check-in found for today' });
    if (attendance.checkOut) return res.status(400).json({ message: 'Already checked out' });

    attendance.checkOut = now;
    await attendance.save();

    await User.findByIdAndUpdate(req.user.id, { isCheckedIn: false });

    res.json({ message: 'Checked out', attendance });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// GET /api/attendance
exports.getAttendance = async (req, res) => {
  try {
    const today = moment().format('YYYY-MM-DD');
    const { date } = req.query;
    const targetDate = date || today;

    const records = await Attendance.find({ date: targetDate });
    const myRecord = await Attendance.findOne({
      employeeId: req.user.id,
      date: targetDate
    });

    res.json({
      date: targetDate,
      records,
      myRecord,
      todayStatus: myRecord
    });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// POST /api/attendance/correction
exports.correction = async (req, res) => {
  try {
    // Simple implementation - aap chahein to alag Correction model bana sakte hain
    const { date, reason } = req.body;
    // Audit log mein record karein
    const { logAudit } = require('../middleware/audit');
    await logAudit(req.user.email, 'Attendance correction requested', `Date: ${date}, Reason: ${reason}`);
    res.json({ message: 'Correction request submitted to HR' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};