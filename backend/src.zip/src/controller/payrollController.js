const Payroll = require('../models/Payroll');
const User = require('../models/User');
const { logAudit } = require('../middleware/audit');
const PDFDocument = require('pdfkit');
const mongoose = require('mongoose');

// GET /api/payroll?month=YYYY-MM
exports.getPayroll = async (req, res) => {
  try {
    const { month } = req.query;
    if (!month) return res.status(400).json({ message: 'Month required (YYYY-MM)' });
    let filter = { month };
    if (req.user.role === 'Employee') {
      filter.employeeId = req.user.id;
    }
    const payrolls = await Payroll.find(filter);
    const isFinalized = payrolls.length > 0 && payrolls.every(p => p.isLocked);
    res.json({
      records: payrolls,
      isFinalized,
      results: payrolls
    });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// POST /api/payroll/generate
exports.generatePayroll = async (req, res) => {
  try {
    const { month } = req.body; // YYYY-MM
    if (!month) return res.status(400).json({ message: 'Month required (YYYY-MM)' });
    const employees = await User.find({ role: { $ne: 'Admin' } }); // Admin ko exclude karein

    const results = [];
    for (const emp of employees) {
      const existing = await Payroll.findOne({ employeeId: emp._id, month });
      if (existing) {
        results.push(existing);
        continue;
      }

      const basic = emp.basicSalary || 0;
      const allowances = Math.round(basic * 0.10); // 10% HRA example
      const deductions = Math.round(basic * 0.05); // 5% PF example
      const gross = basic + allowances - deductions;

      // Simple tax slab
      let tax = 0;
      if (gross > 50000) tax = gross * 0.10;
      else if (gross > 30000) tax = gross * 0.05;

      const netSalary = gross - tax;

      const payroll = await Payroll.create({
        employeeId: emp._id,
        employeeName: emp.name,
        month, basic, allowances, deductions,
        tax: Math.round(tax),
        netSalary: Math.round(netSalary),
        isLocked: false
      });
      results.push(payroll);
    }

    await logAudit(req.user.email, 'Payroll draft generated', `Month: ${month}, Count: ${results.length}`);
    res.json({ message: `Generated ${results.length} payroll records`, results, records: results });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// POST /api/payroll/finalize
exports.finalizePayroll = async (req, res) => {
  try {
    const { month } = req.body;
    if (!month) return res.status(400).json({ message: 'Month required (YYYY-MM)' });
    await Payroll.updateMany({ month }, { isLocked: true });
    await logAudit(req.user.email, 'Payroll finalized/locked', `Month: ${month}`);
    res.json({ message: `Payroll for ${month} locked`, success: true });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// GET /api/payroll/payslip/:id - PDF download
exports.downloadPayslip = async (req, res) => {
  try {
    let payroll = null;
    if (mongoose.Types.ObjectId.isValid(req.params.id)) {
      payroll = await Payroll.findById(req.params.id);
      if (!payroll) {
        const query = { employeeId: req.params.id };
        if (req.query.month) query.month = req.query.month;
        payroll = await Payroll.findOne(query).sort({ createdAt: -1 });
      }
    }

    if (!payroll) {
      return res.status(404).json({ message: 'Payroll record not found' });
    }

    // Role verification
    if (req.user.role === 'Employee' && payroll.employeeId.toString() !== req.user.id) {
      return res.status(403).json({ message: 'Unauthorized to view this payslip' });
    }

    const doc = new PDFDocument({ margin: 40 });
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename=payslip_${payroll.month}_${payroll.employeeName.replace(/\s+/g, '_')}.pdf`);

    doc.pipe(res);
    doc.fontSize(22).fillColor('#4338ca').text('HCM Lite — Official Payslip', { align: 'center' });
    doc.moveDown(0.5);
    doc.fontSize(10).fillColor('#6b7280').text(`Generated on ${new Date().toLocaleDateString()}`, { align: 'center' });
    doc.moveDown(1.5);

    doc.fontSize(12).fillColor('#111827').text(`Employee: ${payroll.employeeName}`);
    doc.text(`Month / Pay Period: ${payroll.month}`);
    doc.text(`Status: ${payroll.isLocked ? 'Finalized / Paid' : 'Draft'}`);
    doc.moveDown();

    doc.strokeColor('#e5e7eb').lineWidth(1).moveTo(40, doc.y).lineTo(550, doc.y).stroke();
    doc.moveDown();

    doc.fontSize(12).fillColor('#374151');
    doc.text(`Basic Salary: $${payroll.basic}`);
    doc.text(`Allowances: $${payroll.allowances}`);
    doc.text(`Deductions: -$${payroll.deductions}`);
    doc.text(`Tax: -$${payroll.tax}`);
    doc.moveDown();

    doc.strokeColor('#e5e7eb').lineWidth(1).moveTo(40, doc.y).lineTo(550, doc.y).stroke();
    doc.moveDown();

    doc.fontSize(14).fillColor('#16a34a').text(`Net Salary: $${payroll.netSalary}`, { underline: true });
    doc.end();
  } catch (err) {
    console.error('downloadPayslip error:', err);
    if (!res.headersSent) {
      res.status(500).json({ message: err.message });
    }
  }
};