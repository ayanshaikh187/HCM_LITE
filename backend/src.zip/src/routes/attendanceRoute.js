const express = require('express');
const router = express.Router();
const { authMiddleware } = require('../middleware/auth');
const { checkIn, checkOut, getAttendance, correction } = require('../controller/attendanceController');

router.post('/check-in', authMiddleware, checkIn);
router.post('/checkin', authMiddleware, checkIn);
router.post('/check-out', authMiddleware, checkOut);
router.post('/checkout', authMiddleware, checkOut);
router.get('/', authMiddleware, getAttendance);
router.post('/correction', authMiddleware, correction);

module.exports = router;