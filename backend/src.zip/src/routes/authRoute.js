const express = require('express');
const router = express.Router();
const { initSetup, login } = require('../controller/authController');

router.post('/setup/init', initSetup);
router.post('/auth/login', login);

module.exports = router;