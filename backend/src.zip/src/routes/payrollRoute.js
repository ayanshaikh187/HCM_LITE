const express = require('express');
const router = express.Router();
const { authMiddleware, adminOnly } = require('../middleware/auth');
const { getPayroll, generatePayroll, finalizePayroll, downloadPayslip } = require('../controller/payrollController');

router.get('/', authMiddleware, getPayroll);
router.post('/generate', authMiddleware, adminOnly, generatePayroll);
router.post('/finalize', authMiddleware, adminOnly, finalizePayroll);
router.get('/payslip/:id', authMiddleware, downloadPayslip);

module.exports = router;