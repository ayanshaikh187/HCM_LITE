const express = require('express');
const router = express.Router();
const { authMiddleware, hrOrAdmin } = require('../middleware/auth');
const { applyLeave, getLeaves, getPendingLeaves, updateLeaveStatus } = require('../controller/leaveController');

// Employee routes
router.get('/', authMiddleware, getLeaves);
router.post('/', authMiddleware, applyLeave);

// HR routes (mounted at /api/hr/leaves and /api/leaves)
router.get('/pending', authMiddleware, hrOrAdmin, getPendingLeaves);
router.patch('/:id', authMiddleware, hrOrAdmin, updateLeaveStatus);

module.exports = router;