const jwt = require('jsonwebtoken');
const User = require('../models/User');

// JWT Verification
const authMiddleware = async (req, res, next) => {
  try {
    const token = req.headers.authorization?.split(' ')[1]; // Bearer <token>
    if (!token) return res.status(401).json({ message: 'No token, authorization denied' });

    const secret = process.env.JWT_SECRET || process.env.JWT_ACCESS_SECRET || 'hcm_lite_jwt_secret_key';
    const decoded = jwt.verify(token, secret);
    req.user = decoded; // { id, role, name, email }
    next();
  } catch (err) {
    res.status(401).json({ message: 'Token is not valid' });
  }
};

// Role guards
const adminOnly = (req, res, next) => {
  if (req.user.role !== 'Admin') {
    return res.status(403).json({ message: 'Admin access required' });
  }
  next();
};

const hrOrAdmin = (req, res, next) => {
  if (!['Admin', 'HR'].includes(req.user.role)) {
    return res.status(403).json({ message: 'HR or Admin access required' });
  }
  next();
};

module.exports = { authMiddleware, adminOnly, hrOrAdmin };