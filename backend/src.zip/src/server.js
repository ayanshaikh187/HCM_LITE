const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
require('dotenv').config();

// Route imports
const authRoutes = require('./routes/authRoute');
const employeeRoutes = require('./routes/employeeRoute');
const attendanceRoutes = require('./routes/attendanceRoute');
const leaveRoutes = require('./routes/leaveRoute');
const payrollRoutes = require('./routes/payrollRoute');
const aiRoutes = require('./routes/aiRoute');
const dashboardRoutes = require('./routes/dashboardRoute');

const app = express();

app.use(cors({
  origin: true,
  credentials: true
}));
app.use(express.json());

// Mount routes
app.use('/api', authRoutes);
app.use('/api/employees', employeeRoutes);
app.use('/api/attendance', attendanceRoutes);
app.use('/api/leaves', leaveRoutes);
app.use('/api/hr/leaves', leaveRoutes);
app.use('/api/payroll', payrollRoutes);
app.use('/api/ai', aiRoutes);
app.use('/api/admin', dashboardRoutes);
app.use('/api/hr', dashboardRoutes);
app.use('/api/employee', dashboardRoutes);
app.use('/api/comms', dashboardRoutes);

app.get('/api/health', (req, res) => res.json({ status: 'ok' }));

const mongoUri = process.env.MONGODB_URI || process.env.MONGO_URI;
mongoose.connect(mongoUri)
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.error('MongoDB error:', err));

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));